from django.shortcuts import render

def index(request):
    return render(request,"account/index.html")

def about(request):
    return render(request,"account/about.html")   

def contact(request):
    return render(request,"account/contact.html")     